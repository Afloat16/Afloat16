import {CONFIG} from './config.mjs';
import {mount} from './addon/app.mjs';
import {verifyLicense} from './shared/license.mjs';
import {STORAGE_KEYS,escapeHtml,webUrl,safeFilename,paidFeature} from './shared/core.mjs';

const $=selector=>document.querySelector(selector), cleanups=[];
let active=true,timer;
let memory={};
const chromeApi=globalThis.browser ?? globalThis.chrome;
async function read(keys){return chromeApi?.storage?.local?await chromeApi.storage.local.get(keys):memory;}
async function write(patch){if(chromeApi?.storage?.local)await chromeApi.storage.local.set(patch);else Object.assign(memory,patch);}
const stored=await read(null);
if(!stored[STORAGE_KEYS.device])await write({[STORAGE_KEYS.device]:crypto.randomUUID()});
function notify(message){if(!active)return;$('#toast').textContent=String(message);$('#toast').hidden=false;clearTimeout(timer);timer=setTimeout(()=>{$('#toast').hidden=true;},6500);}
async function getDeviceId(){return (await read(STORAGE_KEYS.device))[STORAGE_KEYS.device];}
async function status(){const data=await read([STORAGE_KEYS.device,STORAGE_KEYS.license]);return verifyLicense(data[STORAGE_KEYS.license]||'',CONFIG.licensePublicJwk,{deviceId:data[STORAGE_KEYS.device],product:CONFIG.licenseProduct});}
async function gate(feature){if(!paidFeature(CONFIG,feature)){notify('此操作未定义为可用高级功能。');return false;}const result=await status();$('#plan-badge').textContent=result.valid?'PRO':'FREE';if(result.valid)return true;notify('此功能需要本扩展的高级授权码。基础功能可继续使用。');return false;}
function download(data,name,type='application/json'){
  const blob=data instanceof Blob?data:new Blob([typeof data==='string'||data instanceof Uint8Array||data instanceof ArrayBuffer?data:JSON.stringify(data,null,2)],{type});
  const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=safeFilename(name);link.click();setTimeout(()=>URL.revokeObjectURL(url),15000);
}
async function getTargetTab(){
  if(!chromeApi?.tabs)throw new Error('请在 Firefox 中加载此扩展，再在目标网页点击工具栏图标。');
  const selected=Number(new URL(location.href).searchParams.get('tab'));let tab;
  if(Number.isSafeInteger(selected)&&selected>0)tab=await chromeApi.tabs.get(selected);
  else tab=(await chromeApi.tabs.query({active:true,lastFocusedWindow:true}))[0];
  if(!tab||!Number.isSafeInteger(tab.id)||!tab.url)throw new Error('无法读取目标网页。请先在目标网页点击本扩展图标。');
  webUrl(tab.url);return tab;
}
async function runOnPage(func,args=[],options={}){
  const tab=await getTargetTab();if(typeof func!=='function'||!Array.isArray(args))throw new Error('页面操作参数无效。');
  const result=await chromeApi.scripting.executeScript({target:{tabId:tab.id},func,args,...(options.world?{world:options.world}:{})});
  if(result[0]?.error)throw new Error(result[0].error.message||'页面操作失败。');return result[0]?.result;
}
async function inject(file){if(!/^[a-z0-9_.-]+\.(?:m?js)$/iu.test(file))throw new Error('只允许本包固定内容脚本。');const tab=await getTargetTab();await chromeApi.scripting.executeScript({target:{tabId:tab.id},files:[`addon/${file}`]});}
async function message(type,params={}){
  if(!chromeApi?.runtime?.sendMessage)throw new Error('此操作需要运行于 Firefox 扩展。');
  const data=await read([STORAGE_KEYS.device,STORAGE_KEYS.license]);return chromeApi.runtime.sendMessage({type,params,licenseCode:data[STORAGE_KEYS.license]||'',deviceId:data[STORAGE_KEYS.device]});
}
async function native(action,params={}){
  if(!chromeApi?.runtime?.sendNativeMessage)throw new Error('此操作需要受支持浏览器和 Windows 配套程序。');
  const data=await read([STORAGE_KEYS.device,STORAGE_KEYS.license]);let response;
  try{response=await chromeApi.runtime.sendNativeMessage('com.shufflemonkey.addons',{id:crypto.randomUUID(),action,params,licenseCode:data[STORAGE_KEYS.license]||'',deviceId:data[STORAGE_KEYS.device]});}
  catch{throw new Error('尚未连接独立账号窗口配套程序。请按项目说明注册此扩展ID。');}
  if(!response?.ok)throw Object.assign(new Error(response?.error?.message||'配套程序响应无效。'),{code:response?.error?.code});return response.result;
}
const ctx={main:$('#main'),notify,escape:escapeHtml,download,gate,chrome:chromeApi,getTargetTab,runOnPage,inject,config:CONFIG,getDeviceId,message,native,
  getSettings:async()=>{const value=(await read(STORAGE_KEYS.settings))[STORAGE_KEYS.settings];return value&&typeof value==='object'&&!Array.isArray(value)?value:{};},
  setSettings:async patch=>{if(!patch||typeof patch!=='object'||Array.isArray(patch)||['__proto__','constructor','prototype'].some(key=>Object.hasOwn(patch,key)))throw new Error('设置格式无效。');const current=await ctx.getSettings();await write({[STORAGE_KEYS.settings]:{...current,...patch}});},
  onCleanup:fn=>{if(active)cleanups.push(fn);else fn();},isCurrent:()=>active};
document.title=`${CONFIG.name} · 拾序`;
$('#product-name').textContent=CONFIG.name;$('#version-label').textContent=`Firefox ${CONFIG.version} · 本地优先`;
$('#license-product').textContent=`此授权只适用于 ${CONFIG.name}（${CONFIG.licenseProduct}）。`;
$('#device-id').textContent=`安装标识：${await getDeviceId()}`;
$('#feature-help').innerHTML=`<p>${escapeHtml(CONFIG.summary)}</p><h3>免费功能</h3><ul>${CONFIG.freeFeatures.map(t=>`<li>${escapeHtml(t)}</li>`).join('')}</ul><h3>高级功能</h3><ul>${CONFIG.proFeatures.map(t=>`<li>${escapeHtml(t)}</li>`).join('')||'<li>当前未开放高级能力。</li>'}</ul><h3>当前边界</h3><ul>${CONFIG.gaps.map(t=>`<li>${escapeHtml(t)}</li>`).join('')}</ul><p class="result-summary">基础权限：${escapeHtml(CONFIG.permissions.join('、'))}。网站访问只按对应工具需要申请；不同工具能力与权限各自独立。</p>`;
for(const [button,panel]of[['license-toggle','license-panel'],['help-toggle','help-panel']])$("#"+button).addEventListener('click',()=>{const element=$('#'+panel);element.hidden=!element.hidden;$('#'+button).setAttribute('aria-expanded',String(!element.hidden));});
$('#activate-license').addEventListener('click',async()=>{try{const code=$('#license-code').value.trim(),result=await verifyLicense(code,CONFIG.licensePublicJwk,{deviceId:await getDeviceId(),product:CONFIG.licenseProduct});if(!result.valid)throw new Error(`授权验证未通过：${result.reason}`);await write({[STORAGE_KEYS.license]:code});$('#license-code').value='';$('#plan-badge').textContent='PRO';notify('本扩展高级版已激活。');}catch(error){notify(error.message);}});
$('#remove-license').addEventListener('click',async()=>{try{await write({[STORAGE_KEYS.license]:''});$('#plan-badge').textContent='FREE';notify('本地授权码已移除。');}catch(error){notify(error.message);}});
window.addEventListener('pagehide',()=>{active=false;clearTimeout(timer);for(const fn of cleanups.splice(0)){try{fn();}catch{}}},{once:true});
try{const tab=await getTargetTab();$('#target-context').textContent=`目标网页：${tab.title||webUrl(tab.url).hostname} · ${webUrl(tab.url).origin}`;$('#target-context').hidden=false;}catch{}
$('#plan-badge').textContent=(await status()).valid?'PRO':'FREE';
try{await mount(ctx);$('#main').dataset.ready='true';}catch(error){$('#main').innerHTML=`<section class="panel"><h1>${escapeHtml(CONFIG.name)}</h1><p class="status-error">${escapeHtml(error.message)}</p><p class="muted">需要网页权限的功能，请在目标网页点击本扩展的工具栏图标后重试。</p></section>`;$('#main').dataset.failed='true';}
