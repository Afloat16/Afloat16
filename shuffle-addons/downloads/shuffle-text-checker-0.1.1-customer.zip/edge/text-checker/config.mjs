export const CONFIG = Object.freeze({
  "id": "text-checker",
  "name": "拾序文字检查",
  "englishName": "Shuffle Text Check",
  "summary": "在本地标记重复词、常见拼写和空格标点问题。",
  "version": "0.1.1",
  "licenseProduct": "shuffle-addons/text-checker",
  "freeFeatures": [
    "本地规则检查",
    "逐项查看建议",
    "手动应用建议"
  ],
  "proFeatures": [
    "导出检查报告"
  ],
  "paidFeatures": [
    "checker.export"
  ],
  "gaps": [
    "不是完整语法或学术审校",
    "不提供AI改写或远程语言服务"
  ],
  "permissions": [
    "storage"
  ],
  "licensePublicJwk": {
    "kty": "OKP",
    "crv": "Ed25519",
    "x": "Z3chvwximy3TCFYm_PYjE41NzbA5fAUPIyZnRgMJ0Jo",
    "ext": true,
    "key_ops": [
      "verify"
    ]
  },
  "releaseChannel": "firefox-store-candidate",
  "supportEmail": "shufflemonkey@163.com",
  "checkoutEnabled": false,
  "author": "Afloat16",
  "homepageUrl": "https://github.com/Afloat16"
});
