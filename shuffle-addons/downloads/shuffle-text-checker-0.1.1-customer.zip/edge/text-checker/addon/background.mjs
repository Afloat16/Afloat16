export function setupBackground(_ctx) {}

