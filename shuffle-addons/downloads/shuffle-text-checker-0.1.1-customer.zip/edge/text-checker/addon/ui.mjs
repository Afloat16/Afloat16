export function ui(ctx, html) {
  const { main } = ctx; main.innerHTML = html;
  const abort = new AbortController(); let disposed = false;
  const alive = () => !disposed && main.isConnected && (!ctx.isCurrent || ctx.isCurrent());
  const $ = selector => main.querySelector(selector);
  const status = message => { if (alive() && $('#status')) $('#status').textContent = message; };
  const report = error => { if (alive()) { status(error.message || String(error)); ctx.notify(error.message || String(error)); } };
  function on(selector, type, action) { $(selector).addEventListener(type, event => { try { Promise.resolve(action(event)).catch(report); } catch (error) { report(error); } }, { signal: abort.signal }); }
  const dispose = () => { if (disposed) return; disposed = true; abort.abort(); };
  ctx.onCleanup?.(dispose);
  return { $, on, alive, status, report, dispose, chrome: ctx.chrome || globalThis.chrome };
}
export async function settings(ctx) { if (ctx.getSettings) return await ctx.getSettings() || {}; return (await (ctx.chrome || globalThis.chrome).storage.local.get('settings')).settings || {}; }
export async function saveSettings(ctx, patch) { if (ctx.setSettings) return ctx.setSettings(patch); const api = ctx.chrome || globalThis.chrome; const current = (await api.storage.local.get('settings')).settings || {}; await api.storage.local.set({ settings: { ...current, ...patch } }); }
export function response(value) { if (value?.ok === false) throw new Error(value.error?.message || value.error || '后台操作失败。'); return value?.result ?? value; }

