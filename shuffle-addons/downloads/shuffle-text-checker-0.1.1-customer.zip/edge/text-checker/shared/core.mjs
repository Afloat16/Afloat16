export const STORAGE_KEYS = Object.freeze({device:'shuffleDeviceId',license:'shuffleLicenseCode',settings:'settings'});
export const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function webUrl(value) {
  if(typeof value!=='string'||value.length>8192)throw new Error('网页地址无效。');
  const url=new URL(value);
  if(!['http:','https:'].includes(url.protocol)||url.username||url.password)throw new Error('只接受不含账号密码的 HTTP/HTTPS 网页。');
  return url;
}
export function safeFilename(value,fallback='shuffle-export.json') {
  const name=String(value||fallback).replace(/[\\/:*?"<>|\x00-\x1f]/gu,'_').replace(/[. ]+$/u,'').slice(0,180);
  if(!name||/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/iu.test(name))return fallback;
  return name;
}
export function paidFeature(config,feature) {return Array.isArray(config.paidFeatures)&&config.paidFeatures.includes(feature);}
export function isOwnUiSender(chromeApi,sender) {return sender?.id===chromeApi.runtime.id&&typeof sender.url==='string'&&sender.url.startsWith(chromeApi.runtime.getURL(''));}
