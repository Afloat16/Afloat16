/** Browser/Node shared, dependency-free Ed25519 license verifier. No signing keys here. */
export const LICENSE_PREFIX = 'SM1';
export const LICENSE_VERSION = 1;
export const LICENSE_PRODUCT = 'shuffle-tools';
export const MAX_LICENSE_LENGTH = 4096;

const MAX_PAYLOAD_BYTES = 2048;
const MAX_TIMESTAMP = 8_640_000_000_000_000;
const ALLOWED_FIELDS = new Set(['version', 'product', 'licenseId', 'plan', 'issuedAt', 'expiresAt', 'notBefore', 'deviceId']);
const IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._:-]{7,127}$/;
const DEVICE_IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._:-]{15,127}$/;
const encoder = new TextEncoder();

export function encodeBase64Url(bytes) {
  if (!(bytes instanceof Uint8Array)) throw new TypeError('Expected Uint8Array');
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/u, '');
}

function decodeBase64Url(text, maximumBytes) {
  if (typeof text !== 'string' || !/^[A-Za-z0-9_-]+$/u.test(text) || text.length > Math.ceil(maximumBytes * 4 / 3)) {
    throw new Error('Invalid base64url');
  }
  const binary = atob(text.replaceAll('-', '+').replaceAll('_', '/') + '='.repeat((4 - text.length % 4) % 4));
  const bytes = Uint8Array.from(binary, character => character.charCodeAt(0));
  if (bytes.length > maximumBytes || encodeBase64Url(bytes) !== text) throw new Error('Noncanonical base64url');
  return bytes;
}

const isTimestamp = value => Number.isSafeInteger(value) && value >= 0 && value <= MAX_TIMESTAMP;
const isRecord = value => value !== null && typeof value === 'object' && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;

/** Structural validation, also used by the private operator CLI before signing. */
export function validateLicensePayload(payload, product = LICENSE_PRODUCT) {
  if (!isRecord(payload) || Object.keys(payload).some(key => !ALLOWED_FIELDS.has(key))) return { valid: false, reason: 'invalid-payload' };
  if (payload.version !== LICENSE_VERSION) return { valid: false, reason: 'unsupported-version' };
  if (typeof payload.product !== 'string' || payload.product !== product) return { valid: false, reason: 'wrong-product' };
  if (payload.plan !== 'pro') return { valid: false, reason: 'invalid-plan' };
  if (typeof payload.licenseId !== 'string' || !IDENTIFIER.test(payload.licenseId)) return { valid: false, reason: 'invalid-license-id' };
  if (!isTimestamp(payload.issuedAt)) return { valid: false, reason: 'invalid-issued-at' };
  if (payload.expiresAt !== null && (!isTimestamp(payload.expiresAt) || payload.expiresAt <= payload.issuedAt)) return { valid: false, reason: 'invalid-expires-at' };
  if (Object.hasOwn(payload, 'notBefore') && (!isTimestamp(payload.notBefore) || payload.notBefore < payload.issuedAt || (payload.expiresAt !== null && payload.notBefore >= payload.expiresAt))) return { valid: false, reason: 'invalid-not-before' };
  if (Object.hasOwn(payload, 'deviceId') && (typeof payload.deviceId !== 'string' || !DEVICE_IDENTIFIER.test(payload.deviceId))) return { valid: false, reason: 'invalid-device-id' };
  return { valid: true, reason: 'ok' };
}

function publicKeyInput(publicJwk) {
  if (!isRecord(publicJwk) || publicJwk.kty !== 'OKP' || publicJwk.crv !== 'Ed25519' || Object.hasOwn(publicJwk, 'd')) throw new Error('Invalid public key');
  if (decodeBase64Url(publicJwk.x, 32).length !== 32) throw new Error('Invalid public key length');
  // Node commonly omits alg; Edge WebCrypto exports the fully specified Ed25519 name.
  if (Object.hasOwn(publicJwk, 'alg') && !['EdDSA', 'Ed25519'].includes(publicJwk.alg)) throw new Error('Invalid key algorithm');
  if (Object.hasOwn(publicJwk, 'use') && publicJwk.use !== 'sig') throw new Error('Invalid key use');
  if (Object.hasOwn(publicJwk, 'key_ops') && (!Array.isArray(publicJwk.key_ops) || publicJwk.key_ops.length !== 1 || publicJwk.key_ops[0] !== 'verify')) throw new Error('Invalid key operations');
  return { kty: 'OKP', crv: 'Ed25519', x: publicJwk.x, ext: true, key_ops: ['verify'] };
}

/**
 * Verify exact signed bytes, then product/time/device restrictions.
 * Timestamps are Unix milliseconds. Unbound codes are bearer licenses.
 * A device ID is a random installation identifier, never a hardware fingerprint.
 * Returned payloads have passed signature AND structural validation.
 */
export async function verifyLicense(code, publicJwk, { now = Date.now(), deviceId, product = LICENSE_PRODUCT } = {}) {
  if (!isTimestamp(now) || typeof product !== 'string' || product.length < 1 || product.length > 128) return { valid: false, reason: 'invalid-options' };
  if (deviceId !== undefined && (typeof deviceId !== 'string' || !DEVICE_IDENTIFIER.test(deviceId))) return { valid: false, reason: 'invalid-device-id' };
  if (typeof code !== 'string' || code.length < 4 || code.length > MAX_LICENSE_LENGTH || code !== code.trim()) return { valid: false, reason: 'invalid-format' };
  const parts = code.split('.');
  if (parts.length !== 3 || parts[0] !== LICENSE_PREFIX) return { valid: false, reason: 'invalid-format' };
  let payloadBytes;
  let signature;
  let payload;
  try {
    payloadBytes = decodeBase64Url(parts[1], MAX_PAYLOAD_BYTES);
    signature = decodeBase64Url(parts[2], 64);
    if (signature.length !== 64) return { valid: false, reason: 'invalid-format' };
    payload = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(payloadBytes));
  } catch {
    return { valid: false, reason: 'invalid-format' };
  }
  if (publicJwk === null || publicJwk === undefined) return { valid: false, reason: 'key-not-configured' };
  if (!globalThis.crypto?.subtle) return { valid: false, reason: 'crypto-unavailable' };
  let key;
  try {
    key = await globalThis.crypto.subtle.importKey('jwk', publicKeyInput(publicJwk), { name: 'Ed25519' }, false, ['verify']);
  } catch {
    return { valid: false, reason: 'invalid-public-key' };
  }
  try {
    const signedBytes = encoder.encode(`${LICENSE_PREFIX}.${parts[1]}`);
    if (!await globalThis.crypto.subtle.verify({ name: 'Ed25519' }, key, signature, signedBytes)) return { valid: false, reason: 'invalid-signature' };
  } catch {
    return { valid: false, reason: 'verification-failed' };
  }
  const structure = validateLicensePayload(payload, product);
  if (!structure.valid) return structure;
  Object.freeze(payload);
  if (now < payload.issuedAt || (payload.notBefore !== undefined && now < payload.notBefore)) return { valid: false, reason: 'not-yet-valid', payload };
  if (payload.expiresAt !== null && now >= payload.expiresAt) return { valid: false, reason: 'expired', payload };
  if (payload.deviceId !== undefined && deviceId === undefined) return { valid: false, reason: 'device-required', payload };
  if (payload.deviceId !== undefined && payload.deviceId !== deviceId) return { valid: false, reason: 'device-mismatch', payload };
  return { valid: true, reason: 'ok', payload };
}
