const chromeApi = globalThis.browser ?? globalThis.chrome;
import { CONFIG } from './config.mjs';
import { setupBackground } from './addon/background.mjs';
import { verifyLicense } from './shared/license.mjs';
import { STORAGE_KEYS, paidFeature } from './shared/core.mjs';

// Register listeners synchronously so MV3 cold-start events are not lost.
chromeApi.action.onClicked.addListener(tab=>{
  const url=new URL(chromeApi.runtime.getURL('app.html'));
  if(Number.isSafeInteger(tab?.id))url.searchParams.set('tab',String(tab.id));
  chromeApi.tabs.create({url:url.href}).catch(()=>{});
});
async function requirePro(_message,feature) {
  if(!paidFeature(CONFIG,feature))throw Object.assign(new Error('不支持的高级功能。'),{code:'UNKNOWN_FEATURE'});
  const data=await chromeApi.storage.local.get([STORAGE_KEYS.device,STORAGE_KEYS.license]);
  const result=await verifyLicense(data[STORAGE_KEYS.license]||'',CONFIG.licensePublicJwk,{deviceId:data[STORAGE_KEYS.device],product:CONFIG.licenseProduct});
  if(!result.valid)throw Object.assign(new Error('此功能需要有效的本扩展高级授权。'),{code:'PRO_REQUIRED'});
}
export const STARTUP = {ok:false,error:null};
try { setupBackground({config:CONFIG,requirePro,chrome:chromeApi}); STARTUP.ok=true; }
catch(error){STARTUP.error=String(error.message);console.error('Addon background initialization failed:',error.message);}
globalThis.__shuffleAddonStartup = STARTUP;
