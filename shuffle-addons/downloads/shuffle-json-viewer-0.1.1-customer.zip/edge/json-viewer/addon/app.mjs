import { ui } from './ui.mjs';
import { parseJsonExact, formatJsonExact } from './helpers.mjs';
export async function mount(ctx) {
  const v = ui(ctx, `<section class="panel"><h2>JSON 原文与结构</h2><p>本地校验，不执行代码；数字按原始词法保留，大整数、指数及重复键不会被静默转成双精度值。</p><textarea id="json-source" rows="12" spellcheck="false">{"count":9007199254740993,"items":[true,null]}</textarea><div class="toolbar"><button id="validate" class="button primary">校验并查看树</button><button id="format" class="button">格式化到预览</button><button id="page" class="button">读取目标页文本</button><button id="export" class="button">导出格式化 JSON · PRO</button></div><label class="field">本地文件（最大1 MiB）<input id="file" type="file" accept=".json,application/json"></label><p id="status" role="status"></p><div id="tree"></div><pre id="formatted"></pre></section>`);
  let parsed = null;
  function tree(node, label = '$', depth = 0) {
    if (node.type === 'object' || node.type === 'array') { const children = node.type === 'object' ? node.entries.map(entry => [entry.key, entry.value]) : node.items.map((item, index) => [String(index), item]); return `<details${depth < 1 ? ' open' : ''}><summary>${ctx.escape(label)} · ${node.type} (${children.length})</summary><div style="padding-left:18px">${children.map(([name, child]) => tree(child, name, depth + 1)).join('')}</div></details>`; }
    return `<p>${ctx.escape(label)}: <code>${ctx.escape(node.raw)}</code> <small>${node.type}</small></p>`;
  }
  function validate() { parsed = parseJsonExact(v.$('#json-source').value); v.$('#tree').innerHTML = tree(parsed.tree); v.status(`有效 JSON · ${parsed.nodes} 节点${parsed.duplicateKeys.length ? ` · 检测到 ${parsed.duplicateKeys.length} 个重复键（保留）` : ''}`); return parsed; }
  v.on('#validate', 'click', validate);
  v.on('#json-source', 'input', () => { parsed = null; v.$('#tree').textContent = ''; v.$('#formatted').textContent = ''; v.status('原文已变化，请重新校验；旧预览已清除。'); });
  v.on('#format', 'click', () => { v.$('#formatted').textContent = formatJsonExact(validate().tree); });
  v.on('#export', 'click', async () => { const value = formatJsonExact(validate().tree); if (!await ctx.gate('json.export') || !v.alive()) return; ctx.download(value, 'formatted.json', 'application/json'); });
  v.on('#file', 'change', async event => { const file = event.target.files?.[0]; if (!file) return; if (file.size > 1048576) throw new Error('文件最大1 MiB。'); const bytes = await file.arrayBuffer(); const text = new TextDecoder('utf-8', { fatal: true }).decode(bytes); if (!v.alive()) return; v.$('#json-source').value = text; validate(); });
  v.on('#page', 'click', async () => { const text = await ctx.runOnPage(() => { const text = document.querySelector('pre')?.textContent || document.body?.innerText || ''; if (text.length > 1048576) throw new Error('页面文本过大'); return text; }); if (v.alive()) { v.$('#json-source').value = text; validate(); } });
  validate();
}
