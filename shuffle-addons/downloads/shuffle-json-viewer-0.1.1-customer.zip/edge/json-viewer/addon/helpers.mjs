export const JSON_LIMITS = Object.freeze({ bytes: 1048576, nodes: 10000, depth: 100 });
export function parseJsonExact(source) {
  if (typeof source !== 'string' || new TextEncoder().encode(source).length > JSON_LIMITS.bytes) throw new Error('JSON 最大 1 MiB。');
  let at = 0, count = 0; const duplicateKeys = [];
  const fail = message => { throw new Error(`${message}（位置 ${at + 1}）`); };
  const space = () => { while (/[ \t\r\n]/u.test(source[at] || '\0')) at++; };
  function quoted() {
    const start = at++; let escaped = false;
    while (at < source.length) { const char = source[at++]; if (escaped) { escaped = false; continue; } if (char === '\\') escaped = true; else if (char === '"') { const raw = source.slice(start, at); try { return { raw, value: JSON.parse(raw) }; } catch { fail('无效字符串'); } } }
    fail('字符串未结束');
  }
  function value(depth) {
    space(); if (depth > JSON_LIMITS.depth || ++count > JSON_LIMITS.nodes) fail('JSON 嵌套或节点过多');
    const char = source[at];
    if (char === '{') {
      at++; space(); const entries = [], keys = new Set();
      if (source[at] === '}') { at++; return { type: 'object', entries }; }
      while (at < source.length) {
        space(); if (source[at] !== '"') fail('对象键需要双引号'); const key = quoted(); space(); if (source[at++] !== ':') fail('对象缺少冒号');
        if (keys.has(key.value)) duplicateKeys.push(key.value); keys.add(key.value); entries.push({ key: key.value, value: value(depth + 1) });
        space(); if (source[at] === '}') { at++; return { type: 'object', entries }; } if (source[at++] !== ',') fail('对象缺少逗号');
      }
      fail('对象未结束');
    }
    if (char === '[') {
      at++; space(); const items = []; if (source[at] === ']') { at++; return { type: 'array', items }; }
      while (at < source.length) { items.push(value(depth + 1)); space(); if (source[at] === ']') { at++; return { type: 'array', items }; } if (source[at++] !== ',') fail('数组缺少逗号'); }
      fail('数组未结束');
    }
    if (char === '"') return { type: 'string', ...quoted() };
    for (const token of ['true', 'false', 'null']) if (source.startsWith(token, at)) { at += token.length; return { type: token === 'null' ? 'null' : 'boolean', raw: token }; }
    const number = /^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/u.exec(source.slice(at));
    if (number) { at += number[0].length; return { type: 'number', raw: number[0] }; }
    fail('不是有效 JSON 值');
  }
  const tree = value(0); space(); if (at !== source.length) fail('存在多余内容'); return { tree, nodes: count, duplicateKeys };
}
export function formatJsonExact(node, depth = 0) {
  const pad = '  '.repeat(depth), next = '  '.repeat(depth + 1);
  if (node.type === 'object') return node.entries.length ? `{\n${node.entries.map(entry => `${next}${JSON.stringify(entry.key)}: ${formatJsonExact(entry.value, depth + 1)}`).join(',\n')}\n${pad}}` : '{}';
  if (node.type === 'array') return node.items.length ? `[\n${node.items.map(item => next + formatJsonExact(item, depth + 1)).join(',\n')}\n${pad}]` : '[]';
  return node.type === 'string' ? JSON.stringify(node.value) : node.raw;
}
