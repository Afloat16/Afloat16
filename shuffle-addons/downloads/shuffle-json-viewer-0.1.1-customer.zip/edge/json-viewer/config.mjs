export const CONFIG = Object.freeze({
  "id": "json-viewer",
  "name": "拾序JSON树",
  "englishName": "Shuffle JSON Tree",
  "summary": "校验JSON并以可折叠结构查看，保留大数字原始文本。",
  "version": "0.1.1",
  "licenseProduct": "shuffle-addons/json-viewer",
  "freeFeatures": [
    "本地校验",
    "折叠树",
    "无损数字格式化"
  ],
  "proFeatures": [
    "导出格式化JSON"
  ],
  "paidFeatures": [
    "json.export"
  ],
  "gaps": [
    "不执行JavaScript",
    "不自动替换所有JSON网页"
  ],
  "permissions": [
    "storage",
    "activeTab",
    "scripting"
  ],
  "licensePublicJwk": {
    "kty": "OKP",
    "crv": "Ed25519",
    "x": "Z3chvwximy3TCFYm_PYjE41NzbA5fAUPIyZnRgMJ0Jo",
    "ext": true,
    "key_ops": [
      "verify"
    ]
  },
  "releaseChannel": "firefox-store-candidate",
  "supportEmail": "shufflemonkey@163.com",
  "checkoutEnabled": false,
  "author": "Afloat16",
  "homepageUrl": "https://github.com/Afloat16"
});
