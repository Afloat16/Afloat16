Shuffle JSON Tree 0.1.1 — Customer installation guide

This ZIP contains this product only. No actual license codes or seller private keys are included. Publisher: Afloat16.

FREE: Local JSON validation, collapsible tree, exact-number formatted preview, local files and explicit target-page text input.
PRO: Download formatted JSON files. A license does not add capabilities outside the stated scope.

Microsoft Edge (declared minimum 140; tested in 155.0.4283.62):
1. Fully extract to a folder you will keep.
2. Open edge://extensions and enable Developer mode.
3. Choose Load unpacked and select edge/json-viewer/, containing manifest.json. Do not select the whole ZIP or its parent edge folder.
4. Open the tool with its toolbar icon. For JSON page reading, click that icon on the target HTTP(S) page, then explicitly choose Read target-page text.

Firefox (declared minimum 140; tested in 158.0.1):
firefox/json-viewer/ contains unsigned development files, NOT a Mozilla-signed XPI. Permanent installation in standard Firefox requires Mozilla signing or an official store distribution. This ZIP does not claim approval. Use the official listing if available.
For temporary developer testing only, open about:debugging#/runtime/this-firefox, choose Load Temporary Add-on and select firefox/json-viewer/manifest.json. It is removed on Firefox restart. This development ZIP is not a permanent Firefox installer.

Activation and storage:
All FREE features work without a code. A separately purchased product-specific signed code can be entered under License and upgrade. Product: shuffle-addons/json-viewer; codes for other products are not interchangeable. The inventory codes automatically fulfilled for this LDXP offer are pre-signed, unbound codes. They are not technically locked to hardware or an installation ID. One user and one device is a contractual usage term, not a hardware-enforced or online concurrent-device restriction; do not share a code with another user. Before moving to another device, remove the local license and uninstall the old extension, then install and activate it on the new device. Reinstalling, clearing data or changing the installation ID does not by itself require reissuing this inventory code. Its validity period remains as stated on the purchase page and in the code.

The extension still generates a random installation ID, not a hardware fingerprint; this inventory code is not bound to it. Signature verification is offline, with no input or license upload, built-in checkout, automated fulfillment or online device counter. Only a separately customized installation-bound license, explicitly agreed at purchase, may require reissuing after reinstalling, clearing data or migration. That customized bound-license condition does not apply to this inventory offer.
Removing a local code restores FREE, does not request a refund and does not delete saved clock presets or downloaded files. Refund, expiry and transfer terms are those agreed on the actual purchase page.

Limits: Maximum 1 MiB, 10000 nodes, depth 100. Does not execute JavaScript or automatically replace JSON pages. Target-page reading requires a toolbar action on that page; protected browser/store pages may refuse it.
No original-vendor cloud service, existing browser-profile import, Windows companion or native program is needed. Minimum versions are declared targets; only the exact versions above were tested.

Each platform folder contains privacy.html. Inputs are processed locally, with no operator ads, telemetry or automatic uploads. Keep exported files securely yourself.
Support, custom development and privacy requests: shufflemonkey@163.com
Publisher: https://github.com/Afloat16

SHA256SUMS.txt verifies extracted files. Never publish your actual license code.
