export const CITY_ZONES = Object.freeze([['上海','Asia/Shanghai'],['东京','Asia/Tokyo'],['新加坡','Asia/Singapore'],['加德满都','Asia/Kathmandu'],['迪拜','Asia/Dubai'],['伦敦','Europe/London'],['巴黎','Europe/Paris'],['纽约','America/New_York'],['洛杉矶','America/Los_Angeles'],['圣保罗','America/Sao_Paulo'],['悉尼','Australia/Sydney'],['奥克兰','Pacific/Auckland']]);
export function validZone(zone) { if (typeof zone !== 'string' || zone.length > 100) throw new Error('时区无效。'); try { return new Intl.DateTimeFormat('en', { timeZone: zone }).resolvedOptions().timeZone; } catch { throw new Error('请输入有效 IANA 时区，如 Asia/Shanghai。'); } }
export function offsetMinutes(date, zone) {
  validZone(zone); const value = new Intl.DateTimeFormat('en', { timeZone: zone, timeZoneName: 'longOffset' }).formatToParts(date).find(part => part.type === 'timeZoneName')?.value;
  if (value === 'GMT' || value === 'UTC') return 0;
  const match = /^GMT([+-])(\d{2}):(\d{2})(?::(\d{2}))?$/u.exec(value || ''); if (!match) throw new Error('浏览器无法提供UTC偏移。'); return (match[1] === '-' ? -1 : 1) * (+match[2] * 60 + +match[3] + +(match[4] || 0) / 60);
}
export function clockInfo(instant, zone) {
  const date = new Date(instant); if (!Number.isFinite(date.getTime())) throw new Error('基准时刻无效。'); zone = validZone(zone);
  const offset = offsetMinutes(date, zone), year = date.getUTCFullYear(), january = offsetMinutes(new Date(Date.UTC(year,0,15,12)), zone), july = offsetMinutes(new Date(Date.UTC(year,6,15,12)), zone);
  return { zone, local: new Intl.DateTimeFormat('zh-CN', { timeZone: zone, dateStyle:'medium',timeStyle:'medium',hourCycle:'h23' }).format(date), offset, zoneName: new Intl.DateTimeFormat('en', { timeZone:zone,timeZoneName:'long' }).formatToParts(date).find(part=>part.type==='timeZoneName')?.value || zone, seasonal: january !== july, dstLikely: january !== july && offset > Math.min(january,july) };
}
export function validateZones(zones) { if (!Array.isArray(zones) || zones.length < 1 || zones.length > 12) throw new Error('请选择1–12个时区。'); return [...new Set(zones.map(validZone))]; }
