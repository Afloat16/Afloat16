export const CONFIG = Object.freeze({
  "id": "world-clocks",
  "name": "拾序城市时钟",
  "englishName": "Shuffle World Clocks",
  "summary": "并排查看IANA城市时区时间及当前偏移与夏令时变化。",
  "version": "0.1.1",
  "licenseProduct": "shuffle-addons/world-clocks",
  "freeFeatures": [
    "城市时间",
    "指定时刻换算",
    "UTC偏移对比"
  ],
  "proFeatures": [
    "保存命名时区组合"
  ],
  "paidFeatures": [
    "clocks.presets"
  ],
  "gaps": [
    "依赖设备时钟和浏览器时区数据库",
    "不连接校时服务器"
  ],
  "permissions": [
    "storage"
  ],
  "licensePublicJwk": {
    "kty": "OKP",
    "crv": "Ed25519",
    "x": "Z3chvwximy3TCFYm_PYjE41NzbA5fAUPIyZnRgMJ0Jo",
    "ext": true,
    "key_ops": [
      "verify"
    ]
  },
  "releaseChannel": "firefox-store-candidate",
  "supportEmail": "shufflemonkey@163.com",
  "checkoutEnabled": false,
  "author": "Afloat16",
  "homepageUrl": "https://github.com/Afloat16"
});
